<?php

class M_owner_notifications{
    private $db;


    public function __construct(){
        $this->db = new Database;
    }

    public function change_conductor_noti($bus_no){

        
    }

}

?>