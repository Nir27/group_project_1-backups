<div class="navbar">
    <img src="<?php echo URLROOT; ?>/img/logo.png" alt="Logo">

    <ul>
        <li><a href="<?php echo URLROOT; ?>/pages/index">Home</a></li>
        <li><a href="<?php echo URLROOT; ?>/pages/terms_conditions">Terms & Conditions</a></li>
        <li><a href="<?php echo URLROOT; ?>/pages/contact_us">Contact Us</a></li>
    </ul>
</div>