<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/css/admin-style/view.css">
    <script src="https://kit.fontawesome.com/74174153b4.js" crossorigin="anonymous"></script>
    <title><?php echo SITENAME; ?></title>
</head>

<body>

    <?php require APPROOT . '/views/inc/admin_navbar.php' ?>
    
    <div class="main">
        <div class="content-heading">
            <h1>Buses</h1>
            <!-- <hr> -->
        </div>

        <div class="content-table">
            <table class="full-table">
                <tr>
                    <th>Bus No</th>
                    <th>Owner</th>
                    <th>Driver</th>
                    <th>Conductor</th>
                    <th>Root Permit</th>
                    <th>License No</th>
                    <th>Capacity</th>
                    <th>Rating</th>
                </tr>

                
                <tr>
                    <td>NC - 6712</td>
                    <td>669165928V</td>
                    <td>234142C</td>
                    <td>920142C</td>
                    <td>E-201</td>
                    <td>234541245</td>
                    <td>53</td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>NC - 3742</td>
                    <td>689109928V</td>
                    <td>536142C</td>
                    <td>423142C</td>
                    <td>E-603</td>
                    <td>494541245</td>
                    <td>25</td>
                    <td>3</td>
                </tr>
                <tr>
                    <td>NC - 2302</td>
                    <td>979165928V</td>
                    <td>504142C</td>
                    <td>700142C</td>
                    <td>E-001</td>
                    <td>432541245</td>
                    <td>25</td>
                    <td>2</td>
                </tr>
            </table>
        </div>
    </div>
    <!-- </div> -->


</body>

</html>