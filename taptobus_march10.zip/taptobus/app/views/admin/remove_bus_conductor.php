<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/css/admin-style/view.css">
    <script src="https://kit.fontawesome.com/74174153b4.js" crossorigin="anonymous"></script>
    <title><?php echo SITENAME; ?></title>
</head>

<body>

    <?php require APPROOT . '/views/inc/admin_navbar.php' ?>

    <div class="main">
        <div class="content-heading">
            <h1>Bus Conductors</h1>
            <!-- <hr> -->
        </div>

        <div class="content-table">
            <table class="full-table">
                <tr>
                    <th>NTC No</th>
                    <th>First Name</th>
                    <th>Last Lame</th>
                    <th>NIC</th>
                    <th>DOB</th>
                    <th>Address</th>
                    <th>Mobile No</th>
                    <th>Tele No</th>
                    <th>Email</th>
                    <th>Rating</th>
                    <th class="delete-button"></th>
                </tr>
                <tr>
                    <td>234142C</td>
                    <td>Dasith</td>
                    <td>Basnayake</td>
                    <td>992895765V</td>
                    <td>1997-03-24</td>
                    <td>Nugegoda</td>
                    <td>0775896523</td>
                    <td>0912297102</td>
                    <td>dasith@gmail.com</td>
                    <td>5</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
                <tr>
                    <td>234142C</td>
                    <td>Sadun</td>
                    <td>Jayalath</td>
                    <td>992895765V</td>
                    <td>1997-03-24</td>
                    <td>Nugegoda</td>
                    <td>0775896523</td>
                    <td>0912297102</td>
                    <td>sadun@gmail.com</td>
                    <td>5</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
                <tr>
                    <td>234142C</td>
                    <td>Kamal</td>
                    <td>Basnayake</td>
                    <td>992895765V</td>
                    <td>1997-03-24</td>
                    <td>Galle</td>
                    <td>0775896523</td>
                    <td>0912297102</td>
                    <td>kamal@gmail.com</td>
                    <td>2</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
            </table>

        </div>

    </div>



</body>

</html>