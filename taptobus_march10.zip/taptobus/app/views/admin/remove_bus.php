<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/css/admin-style/view.css">
    <script src="https://kit.fontawesome.com/74174153b4.js" crossorigin="anonymous"></script>
    <title><?php echo SITENAME; ?></title>
</head>

<body>

    <?php require APPROOT . '/views/inc/admin_navbar.php' ?>

    <div class="main">
        <div class="content-heading">
            <h1>Buses</h1>
            <!-- <hr> -->
        </div>

        <div class="content-table">
            <table class="full-table">
                <tr>
                    <th>Bus No</th>
                    <th>Owner NIC</th>
                    <th>Driver NTC</th>
                    <th>Conductor NTC</th>
                    <th>Root Permit</th>
                    <th>License No</th>
                    <th>Capacity</th>
                    <th>Rating</th>
                    <th class="delete-button"></th>
                </tr>
                <tr>
                    <td>NC - 9812</td>
                    <td>992166398V</td>
                    <td>234142C</td>
                    <td>434542C</td>
                    <td>E198</td>
                    <td>234541245</td>
                    <td>53</td>
                    <td>4</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
                <tr>
                    <td>NC - 6892</td>
                    <td>982167598V</td>
                    <td>734142C</td>
                    <td>137442C</td>
                    <td>E872</td>
                    <td>7343441245</td>
                    <td>25</td>
                    <td>3</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
                <tr>
                    <td>NC - 1842</td>
                    <td>662167598V</td>
                    <td>533442C</td>
                    <td>237442C</td>
                    <td>E003</td>
                    <td>6343341245</td>
                    <td>53</td>
                    <td>4</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
            </table>

        </div>

    </div>



</body>

</html>