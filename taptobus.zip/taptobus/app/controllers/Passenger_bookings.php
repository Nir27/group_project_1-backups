<?php

class Passenger_bookings extends Controller{
    public function __construct(){
        
    }

    public function booking_details(){
        $this->view('passenger/booking_details');
    }

    public function view_booking_details(){
        $this->view('passenger/view_booking_details');
    }
}