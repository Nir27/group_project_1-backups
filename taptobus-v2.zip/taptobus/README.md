# TapToBus

## Expressway Bus Management System

### How to run
* Download zip file.
* Extract it using "Extract Here".
* Rename it as "taptobus"
* Move it to the htdocs folder in xampp folder in C drive.
* Open xampp sever then run aparche and mysql servers.
* Open web browser and use url "localhost/taptpbus".

### Note
* Couldn't add the .htaccess files
* Mail function isn't implemented
* Did simple changes for the framework
* Implemented passenger register form without email verification
* Implemented login page
* But it didn't direct to any home page of users
* Create home pages for each user and modify user controller and user model
* Removed header.php and footer.php from inc folder in views
* Uploaded the database(for 6 actors)
* Feel free to change relevant table if necessary
* Added navigation bar to the passenger
