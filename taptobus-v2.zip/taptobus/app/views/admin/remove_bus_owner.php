<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/css/admin-style/view.css">
    <script src="https://kit.fontawesome.com/74174153b4.js" crossorigin="anonymous"></script>
    <title><?php echo SITENAME; ?></title>
</head>

<body>

    <?php require APPROOT . '/views/inc/admin_navbar.php' ?>

    <div class="main">
        <div class="content-heading">
            <h1>Bus Owners</h1>
            <!-- <hr> -->
        </div>

        <div class="content-table">
            <table class="full-table">
                <tr>
                    <th>NIC</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Mobile No</th>
                    <th class="delete-button"></th>
                </tr>

                <tr>
                    <td>992710110V</td>
                    <td>Nirodha</td>
                    <td>Buddim</td>
                    <td>nirodha@gmail.com</td>
                    <td>0778651237</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>

                <tr>
                    <td>982340110V</td>
                    <td>Kasun</td>
                    <td>Rajitha</td>
                    <td>kasun@gmail.com</td>
                    <td>0778121237</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>

                <tr>
                    <td>992981110V</td>
                    <td>Namal</td>
                    <td>Kumara</td>
                    <td>namal@gmail.com</td>
                    <td>0778671237</td>
                    <td class="delete-button"><button class="delete-btn">Remove</button></td>
                </tr>
            </table>

        </div>

    </div>



</body>

</html>